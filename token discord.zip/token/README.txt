Obrigado por baixar mais um de meus arquivos

token dll e o executável criado por mim o resto são dlls de uma biblioteca

NÃO REVELE ESTE TOKEN PARA NINGUÉM!!ELE PODE SER USADO POR OUTRA PESSOA PARA HACKEAR SUA CONTA!